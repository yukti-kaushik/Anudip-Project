package com.anudip.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@PrimaryKeyJoinColumn(name = "student_id")
public class Student extends User {

//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer studentId;

    @Past(message = "Enrollment date must be in the past")
    @NotNull(message = "Enrollment date is mandatory")
    private LocalDate enrollmentDate;
    
    //Pending Student Job
    @ManyToMany
    private List<Course> coursesEnrolled;
}
