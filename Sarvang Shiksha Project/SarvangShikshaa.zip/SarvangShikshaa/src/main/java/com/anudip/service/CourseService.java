package com.anudip.service;

import com.anudip.entity.Course;

import java.util.List;

public interface CourseService {
    List<Course> getAllCourses();
    Course getCourseById(Long courseId);
    Course saveCourse(Course course);
    void deleteCourse(Long courseId);
}
