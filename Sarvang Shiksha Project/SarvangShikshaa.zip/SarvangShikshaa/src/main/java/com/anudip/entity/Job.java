package com.anudip.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long jobId;

    @NotBlank(message = "Job title is mandatory")
    private String title;

    @NotBlank(message = "Job description is mandatory")
    private String description;

    @NotBlank(message = "Job type is mandatory")
    private String jobType;

    @NotBlank(message = "Application link is mandatory")
    private String applicationLink;
}
