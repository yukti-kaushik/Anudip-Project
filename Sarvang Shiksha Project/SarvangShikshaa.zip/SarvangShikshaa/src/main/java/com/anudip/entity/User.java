package com.anudip.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Data
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;

    @Column(length = 20, nullable = false)
    @NotBlank(message = "First name is mandatory")
    private String fName;

    @Column(length = 20, nullable = false)
    @NotBlank(message = "Last name is mandatory")
    private String lName;

    @Column(length = 2, nullable = false)
    @Min(value = 0, message = "Age should not be less than 0")
    private int age;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email id is not proper")
    private String email;

    @Column(length = 30, nullable = false)
    @NotBlank(message = "Password is mandatory")
    private String password;

    @Pattern(regexp="(^$|[0-9]{10})", message = "Phone number must be 10 digits")
    private String phone;

    @NotBlank(message = "Role is mandatory")
    private String role;

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}
   
}
