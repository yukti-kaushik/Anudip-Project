package com.anudip.service;

import com.anudip.entity.Lesson;

import java.util.List;

public interface LessonService {
    List<Lesson> getAllLessons();
    Lesson getLessonById(Long lessonId);
    Lesson saveLesson(Lesson lesson);
    void deleteLesson(Long lessonId);
}
