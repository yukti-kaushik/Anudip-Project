package com.anudip.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Scholarship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scholarshipId;

    @NotBlank(message = "Scholarship name is mandatory")
    private String name;

    @NotBlank(message = "Scholarship description is mandatory")
    private String description;

    @NotBlank(message = "Eligibility criteria is mandatory")
    private String eligibility;

    @NotBlank(message = "Application link is mandatory")
    private String applicationLink;

    private double amount;
}
