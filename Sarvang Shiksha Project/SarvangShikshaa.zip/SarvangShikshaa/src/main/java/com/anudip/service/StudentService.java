package com.anudip.service;

import com.anudip.entity.Student;

import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();
    Student getStudentById(Integer studentId);
    Student saveStudent(Student student);
    Student updateStudent(Integer studentId, Student studentDetails);
    void deleteStudent(Integer studentId);
}
