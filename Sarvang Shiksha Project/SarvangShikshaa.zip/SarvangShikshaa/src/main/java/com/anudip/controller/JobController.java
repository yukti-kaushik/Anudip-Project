package com.anudip.controller;

import com.anudip.entity.Job;
import com.anudip.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class JobController {

    private final JobService jobService;

    @Autowired
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    // GET all jobs - http://localhost:8080/jobs/getAll
    @GetMapping("/jobs/getAll")
    public ResponseEntity<List<Job>> getAllJobs() {
        List<Job> jobs = jobService.getAllJobs();
        return ResponseEntity.ok(jobs);
    }

    // GET job by ID - http://localhost:8080/jobs/getById/{jobId}
    @GetMapping("/jobs/getById/{jobId}")
    public ResponseEntity<Job> getJobById(@PathVariable Long jobId) {
        Job job = jobService.getJobById(jobId);
        if (job != null) {
            return ResponseEntity.ok(job);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // POST create job - http://localhost:8080/jobs/addJob
    @PostMapping("/jobs/addJob")
    public ResponseEntity<Job> createJob(@RequestBody Job job) {
        Job createdJob = jobService.saveJob(job);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdJob);
    }

    // DELETE job - http://localhost:8080/jobs/deleteJob/{jobId}
    @DeleteMapping("/jobs/deleteJob/{jobId}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long jobId) {
        jobService.deleteJob(jobId);
        return ResponseEntity.noContent().build();
    }
}
