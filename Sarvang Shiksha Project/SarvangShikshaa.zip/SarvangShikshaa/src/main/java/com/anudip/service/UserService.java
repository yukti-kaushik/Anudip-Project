package com.anudip.service;

import com.anudip.entity.User;

import java.util.List;

public interface UserService {
    List<User> getAllUsers();
    User getUserById(Integer userId);
    User saveUser(User user);
    User updateUser(Integer userId, User userDetails);
    void deleteUser(Integer userId); // Deactivate User
}
