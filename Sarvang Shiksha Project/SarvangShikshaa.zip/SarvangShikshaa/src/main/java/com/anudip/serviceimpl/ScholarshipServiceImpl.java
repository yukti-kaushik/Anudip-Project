package com.anudip.serviceimpl;

import com.anudip.entity.Scholarship;
import com.anudip.repository.ScholarshipRepository;
import com.anudip.service.ScholarshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScholarshipServiceImpl implements ScholarshipService {

    private final ScholarshipRepository scholarshipRepository;

    @Autowired
    public ScholarshipServiceImpl(ScholarshipRepository scholarshipRepository) {
        this.scholarshipRepository = scholarshipRepository;
    }

    @Override
    public List<Scholarship> getAllScholarships() {
        return scholarshipRepository.findAll();
    }

    @Override
    public Scholarship getScholarshipById(Long scholarshipId) {
        Optional<Scholarship> optionalScholarship = scholarshipRepository.findById(scholarshipId);
        return optionalScholarship.orElse(null);
    }

    @Override
    public Scholarship saveScholarship(Scholarship scholarship) {
        return scholarshipRepository.save(scholarship);
    }

    @Override
    public void deleteScholarship(Long scholarshipId) {
        scholarshipRepository.deleteById(scholarshipId);
    }
}
