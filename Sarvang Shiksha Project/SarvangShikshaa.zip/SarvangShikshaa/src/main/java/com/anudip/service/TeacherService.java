package com.anudip.service;

import com.anudip.entity.Teacher;

import java.util.List;

public interface TeacherService {
    List<Teacher> getAllTeachers();
    Teacher getTeacherById(Integer teacherId);
    Teacher saveTeacher(Teacher teacher);
    Teacher updateTeacher(Integer teacherId, Teacher teacherDetails);
    void deleteTeacher(Integer teacherId);
}
