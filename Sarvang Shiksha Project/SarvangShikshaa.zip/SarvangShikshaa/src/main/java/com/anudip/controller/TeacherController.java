package com.anudip.controller;

import com.anudip.entity.Teacher;
import com.anudip.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TeacherController {

    private final TeacherService teacherService;

    @Autowired
    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    // GET all teachers - http://localhost:8080/teachers/getAll
    @GetMapping("/teachers/getAll")
    public ResponseEntity<List<Teacher>> getAllTeachers() {
        List<Teacher> teachers = teacherService.getAllTeachers();
        return ResponseEntity.ok(teachers);
    }

    // GET teacher by ID - http://localhost:8080/teachers/getById/{teacherId}
    @GetMapping("/teachers/getById/{teacherId}")
    public ResponseEntity<Teacher> getTeacherById(@PathVariable Integer teacherId) {
        Teacher teacher = teacherService.getTeacherById(teacherId);
        if (teacher != null) {
            return ResponseEntity.ok(teacher);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // POST create teacher - http://localhost:8080/teachers/addTeacher
    @PostMapping("/teachers/addTeacher")
    public ResponseEntity<Teacher> createTeacher(@RequestBody Teacher teacher) {
        Teacher createdTeacher = teacherService.saveTeacher(teacher);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdTeacher);
    }

    // PUT update teacher - http://localhost:8080/teachers/updateTeacher/{teacherId}
    @PutMapping("/teachers/updateTeacher/{teacherId}")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable Integer teacherId, @RequestBody Teacher teacher) {
        Teacher updatedTeacher = teacherService.updateTeacher(teacherId, teacher);
        if (updatedTeacher != null) {
            return ResponseEntity.ok(updatedTeacher);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE teacher - http://localhost:8080/teachers/deleteTeacher/{teacherId}
    @DeleteMapping("/teachers/deleteTeacher/{teacherId}")
    public ResponseEntity<Void> deleteTeacher(@PathVariable Integer teacherId) {
        teacherService.deleteTeacher(teacherId);
        return ResponseEntity.noContent().build();
    }
}
