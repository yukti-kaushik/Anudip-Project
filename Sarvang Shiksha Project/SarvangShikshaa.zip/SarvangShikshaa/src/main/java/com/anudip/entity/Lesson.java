package com.anudip.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Lesson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lessonId;

    @Column(length = 50, nullable = false)
    @NotBlank(message = "Lesson name is mandatory")
    private String name;

    @Column(length = 255, nullable = false)
    @NotBlank(message = "Lesson description is mandatory")
    private String description;

    private String link;

    @ManyToOne
    private Course course;
}
