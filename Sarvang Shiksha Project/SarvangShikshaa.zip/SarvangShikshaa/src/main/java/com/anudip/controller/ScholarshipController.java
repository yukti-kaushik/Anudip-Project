package com.anudip.controller;

import com.anudip.entity.Scholarship;
import com.anudip.service.ScholarshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ScholarshipController {

    private final ScholarshipService scholarshipService;

    @Autowired
    public ScholarshipController(ScholarshipService scholarshipService) {
        this.scholarshipService = scholarshipService;
    }

    // GET all scholarships - http://localhost:8080/scholarships/getAll
    @GetMapping("/scholarships/getAll")
    public ResponseEntity<List<Scholarship>> getAllScholarships() {
        List<Scholarship> scholarships = scholarshipService.getAllScholarships();
        return ResponseEntity.ok(scholarships);
    }

    // GET scholarship by ID - http://localhost:8080/scholarships/getById/{scholarshipId}
    @GetMapping("/scholarships/getById/{scholarshipId}")
    public ResponseEntity<Scholarship> getScholarshipById(@PathVariable Long scholarshipId) {
        Scholarship scholarship = scholarshipService.getScholarshipById(scholarshipId);
        if (scholarship != null) {
            return ResponseEntity.ok(scholarship);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // POST create scholarship - http://localhost:8080/scholarships/addScholarship
    @PostMapping("/scholarships/addScholarship")
    public ResponseEntity<Scholarship> createScholarship(@RequestBody Scholarship scholarship) {
        Scholarship createdScholarship = scholarshipService.saveScholarship(scholarship);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdScholarship);
    }

    // DELETE scholarship - http://localhost:8080/scholarships/deleteScholarship/{scholarshipId}
    @DeleteMapping("/scholarships/deleteScholarship/{scholarshipId}")
    public ResponseEntity<Void> deleteScholarship(@PathVariable Long scholarshipId) {
        scholarshipService.deleteScholarship(scholarshipId);
        return ResponseEntity.noContent().build();
    }
}
