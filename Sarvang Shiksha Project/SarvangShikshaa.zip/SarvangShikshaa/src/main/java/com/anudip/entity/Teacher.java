package com.anudip.entity;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Entity
@Data
@PrimaryKeyJoinColumn(name = "teacher_id")

public class Teacher extends User {

    @Column(length = 50, nullable = false)
    @NotBlank(message = "Qualification is mandatory")
    private String qualification;

    @Column(nullable = false)
    @NotNull(message = "Experience is mandatory")
    private Integer experience;

    @OneToMany(mappedBy = "teacher")
    private List<Course> coursesTaught;
}
