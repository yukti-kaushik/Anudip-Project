package com.anudip.service;

import com.anudip.entity.Scholarship;

import java.util.List;

public interface ScholarshipService {
    List<Scholarship> getAllScholarships();
    Scholarship getScholarshipById(Long scholarshipId);
    Scholarship saveScholarship(Scholarship scholarship);
    void deleteScholarship(Long scholarshipId);
}
